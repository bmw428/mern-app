
import React from 'react';
import UserForm from './UserForm';

function App() {
  return (
    <div className="App">
      <h1>MERN User App</h1>
      <UserForm />
    </div>
  );
}

export default App;
