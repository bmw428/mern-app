
import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function UserForm() {
  const [form, setForm] = useState({ first_name: '', last_name: '', email: '' });
  const [users, setUsers] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/users').then(res => setUsers(res.data));
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post('http://localhost:5000/api/users', form);
    const res = await axios.get('http://localhost:5000/api/users');
    setUsers(res.data);
    setForm({ first_name: '', last_name: '', email: '' });
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input placeholder="First Name" value={form.first_name} onChange={e => setForm({ ...form, first_name: e.target.value })} />
        <input placeholder="Last Name" value={form.last_name} onChange={e => setForm({ ...form, last_name: e.target.value })} />
        <input placeholder="Email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
        <button type="submit">Submit</button>
      </form>

      <ul>
        {users.map(user => (
          <li key={user._id}>{user.first_name} {user.last_name} - {user.email}</li>
        ))}
      </ul>
    </div>
  );
}
